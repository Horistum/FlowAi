package org.flowlang.conformance

import org.flowlang.capabilities.CompatibilityAnalyzer
import org.flowlang.capabilities.ExecutionReadinessAnalyzer
import org.flowlang.capabilities.ExecutionReadinessStatus
import org.flowlang.capabilities.TargetSelectionAnalyzer
import org.flowlang.adapters.yaml.IntentYamlLoader
import org.flowlang.ai.normalization.AiIntentRequest
import org.flowlang.ai.normalization.ScenarioPackIntentNormalizer
import org.flowlang.generators.manifest.TargetCompatibilityReadinessAnalyzer
import org.flowlang.intent.IntentDecisionAnalyzer
import org.flowlang.modules.ModuleContractAnalyzer
import org.flowlang.modules.ModuleRegistry
import java.io.File
import org.flowlang.generators.manifest.TargetProjectionRegistry

internal class PlanningReadinessChecks(
    rootDir: File,
    registry: ModuleRegistry,
    targets: Map<String, org.flowlang.capabilities.TargetCapability>,
    projections: TargetProjectionRegistry
) : ConformanceCheckSupport(rootDir, registry, targets, projections) {
    fun checks(): List<ConformanceCheck> = listOf(
        checkV034CapabilityModuleContracts(),
        checkV035IntentDecisionModel(),
        checkV036ExecutionPlanPortability(),
        checkV037ExecutionReadinessReport(),
        checkV038TargetSelectionReport()
    )

    private fun checkV034CapabilityModuleContracts(): ConformanceCheck = runCheck("v0.3.4.capability-module-contracts") {
        val report = ModuleContractAnalyzer.analyze(registry)
        val errors = report.issues.filter { it.level == "error" }
        require(report.valid) { "Capability module contract report contains errors: ${errors.joinToString { it.code + " " + it.module + "." + (it.action ?: "") }}" }
        require(report.totals.modules >= 5) { "Expected loaded module descriptors." }
        require(report.totals.actions > 0) { "Capability module contract report must include actions." }
        require(report.modules.any { it.name == "docker" && it.actions.any { action -> action.name == "build" && action.outputs.contains("digest") } }) {
            "Docker build contract must expose image digest output."
        }
        require(report.modules.any { it.actions.any { action -> action.destructive && action.requiresSafety } }) {
            "At least one destructive action must require safety so adapters can enforce gates."
        }
        require(report.totals.targetImplicationActions == 0) {
            "Core module contracts must not own target implications; adapter evidence belongs to target registries."
        }
        require(report.modules.all { module -> module.actions.all { it.targetImplications.isEmpty() } }) {
            "Core module report must remain free of target compatibility claims."
        }
    }

    private fun checkV035IntentDecisionModel(): ConformanceCheck = runCheck("v0.3.5.intent-decision-model") {
        val normalizer = ScenarioPackIntentNormalizer()
        val analyzer = IntentDecisionAnalyzer(registry)

        val cleanup = analyzer.analyze(normalizer.normalize(AiIntentRequest("Cleanup old docker images.")).normalizedIntent)
        require(cleanup.missingDecisions.any { it.field == "safety.cleanup.retention" && it.blocksLowering }) {
            "Cleanup without retention must produce a blocking missing decision."
        }
        require(!cleanup.validForLowering) { "Cleanup without retention must not be valid for lowering in decision report." }

        val backup = analyzer.analyze(normalizer.normalize(AiIntentRequest("Back up PostgreSQL database every night, keep backups for 14 days and notify the team on failure.")).normalizedIntent)
        require(backup.missingDecisions.any { it.field == "schedule.timezone" && it.severity == "recommended" && !it.blocksLowering }) {
            "Backup schedule without timezone must produce a recommended missing decision."
        }

        val migration = analyzer.analyze(normalizer.normalize(AiIntentRequest("Run database migration for orders database to version 2026.06, require approval and verify schema after migration.")).normalizedIntent)
        require(migration.missingDecisions.any { it.field == "safety.backup" && it.blocksLowering }) {
            "Database migration without backup must produce a blocking backup decision."
        }

        val prodDeploy = IntentYamlLoader.loadText("""
            kind: FlowIntentDocument
            name: prod-deploy-without-approval
            workflows:
              - name: cd
                kind: DEPLOY
                steps:
                  - id: deploy
                    capability: DEPLOY
                    params:
                      namespace: prod
                      environment: prod
                      image: billing-api:1.0
        """.trimIndent())
        val prodReport = analyzer.analyze(prodDeploy)
        require(prodReport.safetyGates.any { it.policy == "forbidProductionWithoutApproval" && it.blocksLowering }) {
            "Production deploy without approval must produce a blocking safety gate."
        }
        require(prodReport.missingDecisions.any { it.field == "safety.approval" && it.blocksLowering }) {
            "Production deploy without approval must ask for approval decision."
        }
    }

    private fun checkV036ExecutionPlanPortability(): ConformanceCheck = runCheck("v0.3.6.execution-plan-portability") {
        val artifacts = buildPipeline("jenkins", strict = false)
        val negotiation = CompatibilityAnalyzer(targets).negotiate(artifacts.plan, strict = false)
        require(negotiation.portabilityScore in 0.0..1.0) { "Portability score must be normalized to 0.0..1.0." }
        require(negotiation.targets.all { it.portabilityScore in 0.0..1.0 }) { "Every target must expose a normalized portability score." }
        require(negotiation.portableCapabilities.isNotEmpty()) { "Report must identify capabilities portable across all registered targets." }
        require(negotiation.targetSpecificCapabilities.contains("approval.manual")) { "Manual approval must be marked target-specific when some targets only partially support or reject it." }
        require(negotiation.blockingPortabilityIssues.any { it.target == "tekton" && it.capability == "approval.manual" }) {
            "Report must expose Tekton manual approval as a blocking portability issue."
        }
        require(negotiation.requiredWorkarounds.any { it.target == "github-actions" && it.capability == "approval.manual" }) {
            "Report must expose GitHub Actions manual approval as a target-specific workaround."
        }
    }

    private fun checkV037ExecutionReadinessReport(): ConformanceCheck = runCheck("v0.3.7.execution-readiness") {
        val artifacts = buildPipeline("jenkins", strict = false)
        val compatibility = CompatibilityAnalyzer(targets)
        val analyzer = ExecutionReadinessAnalyzer(targets)

        val preliminaryJenkins = analyzer.analyze(artifacts.plan, "jenkins", strict = false)
        require(preliminaryJenkins.readiness == ExecutionReadinessStatus.READY) { "Jenkins capability readiness should pass before manifest evaluation." }
        require(!preliminaryJenkins.productionReady) { "Capability readiness alone must not claim production readiness." }
        require(!preliminaryJenkins.readinessEvidenceAvailable) { "Preliminary readiness must expose missing artifact evidence." }
        val jenkins = TargetCompatibilityReadinessAnalyzer.reconcile(preliminaryJenkins, artifacts.manifest)
        require(jenkins.readiness == ExecutionReadinessStatus.DEGRADED) { "Reference Jenkins manifest must be review-only." }
        require(!jenkins.productionReady && !jenkins.executable) { "Review-only Jenkins manifest must not be production-ready." }
        require(jenkins.readinessEvidenceAvailable) { "Concrete Jenkins readiness must carry manifest evidence." }

        val githubManifest = manifestPipeline.generateDiagnosticEvidence(artifacts.plan, "github-actions")
        val github = TargetCompatibilityReadinessAnalyzer.reconcile(
            analyzer.analyze(artifacts.plan, "github-actions", strict = false),
            githubManifest
        )
        require(github.readiness == ExecutionReadinessStatus.BLOCKED) { "GitHub Actions must be blocked without workspace continuity evidence." }
        require(!github.generationAllowed && !github.productionReady && !github.executable) {
            "Blocked GitHub Actions evidence must not claim le) {
    n yExpressionNode ->  !greconcile(
      al github = TargetCompatibilityReadinessAnalyzer.reconcile(
            analyzer.analyze(artifacts.plan, "github-actions", strict = false),
            githubManifest
        )
        require(github.readiness == ExecutionReadinessStatus.BLOCKED) { "GitHub A" }) {
            plan, "github-actions", strict = false),
            githubManifest
        )
        require(github.readiness == ExecutionReadinessStatus.BLOCKED) { "GitHub A" }) {
   e must       al githufacts.plp.missingDecisions.any { it.field == "schedule.timezone" && it.severity == """""missingD
        }
   == "schedule.timeliminaryJenkinsNode -> nod    ult                      image: billing-api:1.0
   acts.plp.missingDecisions.any { it.fieid
 aaaaaaaaa
        is SetNode -> { val id = ctx.id("set"); ctx.resulhnSetNode -> { val id = ctx. id = ctx.id("set"s.plan, "jenkins  require(!jrmanceCheck = runCheck("v0orkspace conti id = ctx.id("setc        require(negotiatiU    requiroiness == uest       Approval5aaaaa1val itx.id("setc+action)
        v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot       v ult,(cot   essStatus.BLOCKED) { "GitHub A" }) {
            plan, "github-actions", strict = false),
            githubManminaryJen  githubMassStatus.BLOCKEDraetc+action)
 awMtx.id("set.uLuctionReadyEus.-sct = false)
  uoeeeeeeeeltus.BLOCKEEEEEEEEEEEEEEEEEE          tseyd = ctx. id = ctx.id("set"s.ple),be b       v ult,(cot         uitpnderer.adaaad("sit back(7)quest("Clan.ple),be b       v ult,(cot     image: billiditpnderer.adaaad("sit back(lfnChBErst.     uitpnderer.adaaad("sit back(7)quest("Clan.ple),be b       v ult,(cot     image: billiditpnderer.adaaad("sit   va0tlst("= manifeste b       e),be b       v ulstry,
    targets: M(7)questSiustm   veeeea"sit b v ulstry,
    1quest("Clan.p   githueah   ility == tions manual approiiiiiii'ad("sit   va0tlst("= manid(t,(cot       v ules.fiErBelass PlanningReadinessChecks(
    rooteULE" - "gRse")
        if (action.module ==lanid(t,(cot
            plan, "gis.-sct = false)
  uoeeeeee  uoeeeeee  uoeeeeee  uoeeeeee  uoeeeeee  uoeeeeee  uoeeeeee  uoeeeeee  uoeeee    e),be b dst("= manidisstpndere, "gi conti id = ctx.id("setc  p   githueah   ilM.} e),be b rigg
        """     Approvtry,
 minaryJeee  uoeeeee:.`= faissingDecisions.any { it.fy { ion."
I githubManminaryJen  githubMnin   evidenceRed("sit   va0tl